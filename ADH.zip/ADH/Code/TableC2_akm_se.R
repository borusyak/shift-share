setwd("/Users/kirillborusyak/Dropbox/Ideas/Bartik/BHJ Replication package/ADH")
source("Code/iv.R") # the command from Adao et al. (2019)
loclevel <- read.csv("Data/location_level.csv")
shares <- as.matrix(read.csv("Data/Lshares_superwide.csv"))
sector_clus <- as.matrix(read.csv("Data/sic3.csv"))
adhcontrols <- c("t2","reg_midatl","reg_encen","reg_wncen","reg_satl","reg_escen","reg_wscen","reg_mount","reg_pacif",
              "l_sh_popedu_c","l_sh_popfborn","l_sh_empl_f","l_sh_routine33","l_task_outsource")
col1_controls <- c("l_shind_manuf_cbp")
col2_controls <- c("Lsh_manuf")
col3_controls <- c("Lsh_manuf","Lsh_manuf_t2")
col4_controls <- c(paste("Lsh_sicgroup_",1:10,sep=""),paste("Lsh_sicgroup_",1:10,"_t2",sep="")) # 10 is baseline

res <- matrix(nrow=4,ncol=6)
colnames(res) <- c("col1","col2","col3","col4","fals_col3","fals_col4")
rownames(res) <- c("coef","AKM_SE","AKM0_left","AKM0_right")

r <- with(loclevel, ivreg_ss.fit(y1=y, y2=x, X=z, Z=cbind(1,as.matrix(loclevel[,c(adhcontrols,col1_controls)])), 
                                 W=shares, w=wei, method=c("akm","akm0"), sector_cvar=sector_clus))
res[,1] <- c(r$beta, r$se["AKM"], r$ci.l["AKM0"], r$ci.r["AKM0"])

r <- with(loclevel, ivreg_ss.fit(y1=y, y2=x, X=z, Z=cbind(1,as.matrix(loclevel[,c(adhcontrols,col2_controls)])), 
                                 W=shares, w=wei, method=c("akm","akm0"), sector_cvar=sector_clus))
res[,2] <- c(r$beta, r$se["AKM"], r$ci.l["AKM0"], r$ci.r["AKM0"])

r <- with(loclevel, ivreg_ss.fit(y1=y, y2=x, X=z, Z=cbind(1,as.matrix(loclevel[,c(adhcontrols,col3_controls)])), 
                                 W=shares, w=wei, method=c("akm","akm0"), sector_cvar=sector_clus))
res[,3] <- c(r$beta, r$se["AKM"], r$ci.l["AKM0"], r$ci.r["AKM0"])

r <- with(loclevel, ivreg_ss.fit(y1=y, y2=x, X=z, Z=cbind(1,as.matrix(loclevel[,c(adhcontrols,col4_controls)])), 
                                 W=shares, w=wei, method=c("akm","akm0"), sector_cvar=sector_clus))
res[,4] <- c(r$beta, r$se["AKM"], r$ci.l["AKM0"], r$ci.r["AKM0"])

r <- with(loclevel, ivreg_ss.fit(y1=lagged_y, y2=x, X=z, Z=cbind(1,as.matrix(loclevel[,c(adhcontrols,col3_controls)])), 
                                 W=shares, w=wei, method=c("akm","akm0"), sector_cvar=sector_clus))
res[,5] <- c(r$beta, r$se["AKM"], r$ci.l["AKM0"], r$ci.r["AKM0"])

r <- with(loclevel, ivreg_ss.fit(y1=lagged_y, y2=x, X=z, Z=cbind(1,as.matrix(loclevel[,c(adhcontrols,col4_controls)])), 
                                 W=shares, w=wei, method=c("akm","akm0"), sector_cvar=sector_clus))
res[,6] <- c(r$beta, r$se["AKM"], r$ci.l["AKM0"], r$ci.r["AKM0"])

write.csv(res, "Results/TableC2_akm_se.csv")
