library(VGAM)
library(AER)
library(MASS)
library(sandwich)
library(lmtest)
indlevel <- shares <- loclevel <- indlevel0 <- shares0 <- loclevel0 <-
  dataset <- controls <- M_controls <-ind_controls <- M_ind_controls <- N <- RESULTS <- NULL

ReadADH <- function(dataset) {
  dataset <<- dataset
  if (dataset=="sic87dd") {
    L0 <<- L <<- 1444
    N0 <<- N <<- 794
    indlevel0 <<- read.csv("Data/shocks.csv")
    shares0 <<- matrix(sapply(read.csv("Data/shares_superwide.csv"),as.numeric)[,-(1:2)],nrow=L)
    loclevel0 <<- read.csv("Data/location.csv")
  }
  if (dataset=="sic3") {
    L0 <<- L <<- 1444
    N0 <<- N <<- 272
    indlevel0 <<- read.csv("Data/shocks_sic3.csv")
    shares0 <<- matrix(sapply(read.csv("Data/shares_superwide_sic3.csv"),as.numeric)[,-(1:2)],nrow=L)
    loclevel0 <<- read.csv("Data/location_sic3.csv")
  }
  if (dataset=="sic2") {
    L0 <<- L <<- 1444
    N0 <<- N <<- 40
    indlevel0 <<- read.csv("Data/shocks_sic2.csv")
    shares0 <<- matrix(sapply(read.csv("Data/shares_superwide_sic2.csv"),as.numeric)[,-(1:2)],nrow=L)
    loclevel0 <<- read.csv("Data/location_sic2.csv")
  }
  loclevel0$fs_coef <<- loclevel0$fs_coef[1]
}

LoadADH <- function(keep.obs=NULL, HHI=NULL) {
  if (is.null(keep.obs)) keep.obs <- seq_len(L0)
  loclevel <- loclevel0[keep.obs,]
  shares <- shares0[keep.obs,]
  L <<- nrow(shares)
  
  # need to remove industries which have zero weight now
  keep_ind <- as.vector(loclevel$wei %*% shares)>0 # T/F vector
  shares <- shares[,keep_ind]
  indlevel <- indlevel0[keep_ind,]
  N <<- nrow(indlevel) # WARNING: autcorr structure is now broken, do not use simtype==4 or 5
  
  indlevel$abs_g_dm <- abs(indlevel$g_dm)
  censusdiv.list <- c("reg_midatl","reg_encen","reg_wncen","reg_satl","reg_escen","reg_wscen","reg_mount","reg_pacif","reg_neng")
  keep_div <- censusdiv.list[colSums(loclevel[,censusdiv.list])>0]
  # check which divisions are present (may depend on sumsample), keep all but one
  control.list <- c("t2","Lsh_manuf","Lsh_manuf_t2","l_sh_popedu_c","l_sh_popfborn","l_sh_empl_f",
                    "l_sh_routine33","l_task_outsource",keep_div[1:(length(keep_div)-1)] )
  controls <<- as.matrix(cbind(1,loclevel[,control.list]))
  loclevel$wei <- loclevel$wei/sum(loclevel$wei)
  indlevel$s_n <- as.vector(loclevel$wei %*% shares) # do not sum to one because of incomplete shares

  if (!is.null(HHI)) {
    employment <- loclevel$wei * shares * L*N # the (L*N) term is innocuous, just so that numbers are not so tiny
    nonmfg <- loclevel$wei * (1-rowSums(shares)) *L*N
    mh <- match_hhi(indlevel$s_n, HHI)
    employment <- t( t(employment) * mh$mult * indlevel$s_n^(mh$alpha-1)) 
    # we have to change the regional weight to equal the reg.employment (mfg+serv) so that s_n is as we want
    # a downside is that the mfg share of the economy changes a lot (which is not a big problem since we drop non-mfg)
    loclevel$wei <- rowSums(employment)+nonmfg
    shares <- employment/loclevel$wei
    loclevel$wei <- loclevel$wei/sum(loclevel$wei)
   # stopifnot(sd(as.vector(loclevel$wei %*% shares)/indlevel$s_n^mh$alpha)<10^-6) # by construction s_n is prop to old s_n^alpha
    indlevel$s_n <- as.vector(loclevel$wei %*% shares) 
    employment <- NULL
    
    # regenerate x and z now---but doesn't matter for the simulation anyway. Still doesn't work with fsmult!=1
    loclevel$x <- loclevel$x + loclevel$fs_coef[1] * (shares %*% indlevel$g - loclevel$z) # this way preserve the control part of x
    loclevel$z <- shares %*% indlevel$g
  }

  M_controls <<- diag(L)-controls%*%solve(t(controls)%*%diag(loclevel$wei)%*%controls, t(controls)%*%diag(loclevel$wei))
  indlevel$eps_n <- as.vector((loclevel$wei*loclevel$eps) %*% shares) / indlevel$s_n
  indlevel$x_n <- as.vector(t(loclevel$wei*(M_controls%*%loclevel$x)) %*% shares) / indlevel$s_n
  indlevel$z_n <- as.vector(t(loclevel$wei*(M_controls%*%loclevel$z)) %*% shares) / indlevel$s_n
  indlevel$t2 <- as.numeric(indlevel$year==2000) # industry controls
  indlevel$ind_c <- factor(indlevel$ind)
  indlevel$indgroup_c <- factor(floor(indlevel$ind/10))
  ind_controls <<- cbind(1,as.numeric(indlevel$year==2000)) # 1 and year dummies for now
  indlevel$noclus <- as.factor(seq_len(N)) # each obs is its own cluster
  M_ind_controls <<- diag(N)-ind_controls%*%solve(t(ind_controls)%*%diag(indlevel$s_n)%*%ind_controls,
                                                  t(ind_controls)%*%diag(indlevel$s_n))
  
  # now save stuff to the superenviroment
  indlevel <<- indlevel
  loclevel <<- loclevel
  shares <<- shares
}

SimulADH <- function(name, simtype, SIM=10000, clustervar=NULL, seed=12345, post.results=T, fscoef_mult=1) {
  # simtype: 0=actual data, 1=normal, 2=wild bootstrap

  if (!is.null(seed)) set.seed(seed)
  BETA <- AKM_SE <- AKM0_T <- AKM0_inf <- AR_T <- AR_inf <- ROT5 <- Fstat <- Fnaive <- rep(NA,SIM)
  for (s in 1:SIM) {
    # Generate shocks
    if (simtype==0) indlevel$G <- indlevel$g_dm
    if (simtype==1) indlevel$G <- rnorm(N, sd=sd(indlevel$g_dm))
    if (simtype==2) indlevel$G <- rnorm(N)*indlevel$g_dm
    
    # Construct Z -> X -> ssaggregate
    Z <- as.vector(shares %*% indlevel$G)
    Z_perp <- M_controls %*% Z
    X_perp <- M_controls %*% (loclevel$fs_coef[1] * fscoef_mult * Z + loclevel$x_resid)
    indlevel$X_n <- as.vector(t(loclevel$wei*X_perp) %*% shares) / indlevel$s_n
    indlevel$Z_n <- as.vector(t(loclevel$wei*Z_perp) %*% shares) / indlevel$s_n
    indlevel$G_dm <- M_ind_controls%*%indlevel$G
    
    # Run industry-level IV, collect coef and SE. Truth is zero
    fit <- ivreg(eps_n ~ X_n + t2 | G+t2, data=indlevel, weights=s_n)
#      fsfit <- lm(X_n ~ G+t2, data=indlevel, weights=s_n) # very weird: after lm, summary() produces wrong SE!
    naivefsfit <- ivreg(X_n ~ G+t2 | G+t2, data=indlevel, weights=s_n)
    fsfit <- ivreg(X_n ~ Z_n+t2 | G+t2, data=indlevel, weights=s_n)
    epsfit <- ivreg(eps_n ~ G+t2 | G+t2, data=indlevel, weights=s_n) # eps_n = eps_n - beta0*X_n; naive SE
    BETA[s] <- fit$coefficients[2]
    if (is.null(clustervar)) {
        AKM_SE[s] <- summary(fit, vcov=sandwich)$vcov[2,2]^0.5
        Fnaive[s] <- summary(naivefsfit, vcov=sandwich)$coefficients[2,3]^2 # 3rd column is t-stats
        Fstat[s] <- summary(fsfit, vcov=sandwich)$coefficients[2,3]^2 # 3rd column is t-stats
    }
    else {
      AKM_SE[s] <- coeftest.cluster(indlevel, fit, cluster1=clustervar)[2,2]
      Fnaive[s] <- coeftest.cluster(indlevel, naivefsfit, cluster1=clustervar)[2,3]^2
      Fstat[s] <- coeftest.cluster(indlevel, fsfit, cluster1=clustervar)[2,3]^2
    }
    # Does NOT exactly coincide with Stata clustered SE? Maybe DF correction?
    # Comes from https://iangow.wordpress.com/2012/01/19/iv-regression-and-two-way-cluster-robust-standard-errors/
    # Also note that I had to correct this command so that it works with weights
    

    # Test AKM0 rejection
    if (is.null(clustervar)) {
      AKM0_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum((s_n * eps_n * G_dm)^2)^0.5)
      AKM0_Tinf <- with(indlevel, sum(s_n*X_n*G)/sum((s_n*X_n*G_dm)^2)^0.5) 
      AR_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum((s_n * epsfit$residuals * G_dm)^2)^0.5)
    }
    else {
      clussums <- with(indlevel, tapply(s_n * eps_n * G_dm, indlevel[,clustervar], sum))
      AKM0_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum(clussums^2)^0.5)

      clussums_inf <-  with(indlevel, tapply(s_n * X_n * G_dm, indlevel[,clustervar], sum))
      AKM0_Tinf <- with(indlevel, sum(s_n*X_n*G) / sum(clussums_inf^2)^0.5)

      clussums_ar <-  with(indlevel, tapply(s_n * epsfit$residuals * G_dm, indlevel[,clustervar], sum))
      AR_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum(clussums_ar^2)^0.5)
    }
    AKM0_inf[s] <- abs(AKM0_Tinf)<1.96
    AR_inf[s] <- Fnaive[s] < 1.96^2 # Andrews and Stock show that AR CI is infinite iff the first stage is insignificant
      # see https://www.nber.org/econometrics_minicourse_2018/2018si_methods.pdf, slide 45
    
    # Compute Rotember weight of top-5 industries
    indlevel$ROTweight <- with(indlevel, s_n*G*X_n)
    ROT5[s] <- with(indlevel,sum(ROTweight[rank(-ROTweight)<=5])/sum(ROTweight[ROTweight>0]))
  }
  # Return mean/median ROT5 weight and coverage for AKM and AKM0
  AKM_T <- BETA/AKM_SE
  hhi <- with(indlevel, sum(s_n^2)/sum(s_n)^2)
  
  results <-matrix(c(mean(abs(AKM_T)>1.96), mean(abs(AKM0_T)>1.96), mean(abs(AR_T)>1.96), mean(AKM0_inf), mean(AR_inf),
                    median(ROT5), mean(ROT5), 1/hhi, median(Fstat), mean(Fstat), median(Fnaive), mean(Fnaive),
                    median(BETA), mean(BETA), sd(BETA), mad(BETA), median(AKM_SE), mean(AKM_SE), sd(AKM_SE)),nrow=1)
  colnames(results) <- c("AKM rej rate", "AKM0 rej rate", "AR rej rate", "AKM0 inf rate", "AR inf rate",
                         "Median ROT5", "Mean ROT5", "1/HHI", "Median F", "Mean F", "Med. F naive", "Mean F naive",
                         "Med. Bias", "Mean bias", "Simulated SD", "Simulated MAD", "Median AKM SE", "Mean AKM SE", "SD of AKM SE")
  rownames(results) <- name
  if(post.results) RESULTS <<- rbind(RESULTS,results)
  
  resmatrix <- cbind(AKM_T,AKM0_T,AR_T,AKM0_inf,AR_inf,ROT5,Fstat,Fnaive,BETA,AKM_SE)
  colnames(resmatrix) <- c("AKM_T","AKM0_T","AR_T","AKM0_inf","AR_inf","ROT5","Fstat","Fnaive","BETA","AKM_SE")
  
  return(list(results=results,resmatrix=resmatrix))
}

# Find the power alpha such that HHI(s_n^alpha)=x. Return s_n^alpha. This function increases in alpha
match_hhi <- function(s, HHI, tol=0.0001) {
  if (HHI<1/length(s)) return(NULL)
  left <- log(0.0001)
  right <- log(100)
  mid <- (left+right)/2  
  alpha <- exp(mid)
  hhi <- sum(s^(2*alpha))/(sum(s^alpha)^2)
  it <- 0
  
  while (abs(hhi/HHI - 1)>tol & it<20) {
    if (hhi<HHI) left <- mid
    else right <- mid
    mid <- (left+right)/2
    alpha <- exp(mid)
    hhi <- sum(s^(2*alpha))/(sum(s^alpha)^2)
    it <- it+1
  }
  mult <- sum(s)/sum(s^alpha)
  return(list(alpha=alpha,mult=mult))
}


