setwd("/Users/kirillborusyak/Dropbox/Ideas/Bartik/BHJ Replication package/MonteCarlo")

### FIRST AADHP (faster) ###
rm(list = ls())
SIM <- 10000
source("Code/coeftest.cluster.R")
source("Code/Sim_AADHP.r")

ReadAADHP("sic87dd")
LoadAADHP()

SimulAADHP("Actual data", 0, 10, clustervar = "sic3")$results
SimulAADHP("Normal shocks", 1, SIM)$results
SimulAADHP("Wild bootstrap", 2, SIM)$results

#### Change HHI
LoadAADHP(HHI=1/50)
SimulAADHP("HHI=1/50", 2, SIM)$results
LoadAADHP(HHI=1/20)
SimulAADHP("HHI=1/20", 2, SIM)$results
LoadAADHP(HHI=1/10)
SimulAADHP("HHI=1/10", 2, SIM)$results

### Aggregate to SIC3
ReadAADHP("sic3")
LoadAADHP()
SimulAADHP("SIC3 actual data", 0, 10)$results
SimulAADHP("SIC3 wild bootstrap", 2, SIM)$results

### Aggregate to SIC2
ReadAADHP("sic2")
LoadAADHP()
SimulAADHP("SIC2 actual data", 0, 10)$results
SimulAADHP("SIC2 wild bootstrap", 2, SIM)$results

write.csv(RESULTS, "Results/TableC6_AADHP.csv")

#### NOW ADH ####
rm(list = ls())
SIM <- 10000
source("Code/coeftest.cluster.R")
source("Code/Sim_ADH.r")

ReadADH("sic87dd")
LoadADH()

SimulADH("Actual data", 0, 10, clustervar = "indgroup_c")$results
SimulADH("Normal shocks", 1, SIM)$results
SimulADH("Wild bootstrap", 2, SIM)$results

#### Change HHI ####
LoadADH(HHI=1/50)
SimulADH("HHI=1/50", 2, SIM)$results
LoadADH(HHI=1/20)
SimulADH("HHI=1/20", 2, SIM)$results
LoadADH(HHI=1/10)
SimulADH("HHI=1/10", 2, SIM)$results

#### Aggregate to SIC3 level
ReadADH("sic3")
LoadADH()
SimulADH("SIC3 actual data", 0, 10)$results
SimulADH("SIC3 wild bootstrap", 2, SIM)$results

#### Aggregate to SIC2-level
ReadADH("sic2")
LoadADH()
SimulADH("SIC2 actual data", 0, 10)$results
SimulADH("SIC2 wild bootstrap", 2, SIM)$results

#### Small L
IT <- 100 # number of redrawings of the sample
ReadADH("sic87dd")
for (Lsmall in c(100,25)) {
  set.seed(12345)
  results<-NULL
  for (it in 1:IT) {
    samp <- sample(seq_len(L0/2), Lsmall)
    keep.obs <- c(samp, samp+L0/2)
    LoadADH(keep.obs)
    res <- SimulADH(paste("L=",Lsmall,"*2",sep=""), 2, SIM/IT, seed=NULL, post.results=F)
    if (is.null(results)) results <- res$results
    else results <- results+res$results
    # WARNING: medians are really means of medians; can recover full medians from $resmatrix
  }
  results <- results/IT
  RESULTS <<- rbind(RESULTS,results)
}

write.csv(RESULTS, "Results/TableC6_ADH.csv")
