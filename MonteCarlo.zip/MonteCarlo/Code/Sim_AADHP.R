library(VGAM)
library(AER)
library(MASS)
library(sandwich)
library(lmtest)
indlevel <- indlevel0 <- dataset <- controls <- M_controls <- N <- RESULTS <- NULL

ReadAADHP <- function(dataset) {
  dataset <<- dataset
  if (dataset=="sic87dd") {
    N0 <<- N <<- 784
    indlevel0 <- read.csv("Data/ind_regs.csv")
  }
  if (dataset=="sic3") {
    N0 <<- N <<- 270
    indlevel0 <<- read.csv("Data/ind_regs_sic3.csv")
  }
  if (dataset=="sic2") {
    N0 <<- N <<- 40
    indlevel0 <<- read.csv("Data/ind_regs_sic2.csv")
  }
  indlevel0$t2 <- as.numeric(indlevel0$year==2000) # industry controls
  fs <- lm(x_n ~ g + t2, data=indlevel0, weights=s_n)
  indlevel0$fs_coef <- NA
  indlevel0$fs_coef[1] <- fs$coefficients["g"]
  indlevel0$x_resid <- resid(fs)
  indlevel0 <<- indlevel0
}

LoadAADHP <- function(HHI=NULL) {
  indlevel <- indlevel0
  indlevel$abs_g_dm <- abs(indlevel$g_dm)

  if (!is.null(HHI)) {
    mh <- match_hhi(indlevel$s_n, HHI)
    indlevel$s_n <- indlevel$s_n^(mh$alpha) # no need for multiplier here
  }
  
  controls <<- cbind(1,indlevel$t2)
  M_controls <<- diag(N)-controls%*%solve(t(controls)%*%diag(indlevel$s_n)%*%controls, t(controls)%*%diag(indlevel$s_n))
  indlevel$ind_c <- factor(indlevel$ind)
  
  indlevel <<- indlevel
}

SimulAADHP <- function(name, simtype, SIM=10000, clustervar=NULL, seed=12345, post.results=T, fscoef_mult=1) {
  # simtype: 0=original shock, 1=normal, 2=wild bootstrap
  
  if (!is.null(seed)) set.seed(seed)
  BETA <- Fstat <- AKM_SE <- AKM0_T <- AKM0_inf <- AR_T <- AR_inf <- ROT5 <- rep(NA,SIM)
  for (s in 1:SIM) {
    # Generate shocks
    if (simtype==0) indlevel$G <- indlevel$g_dm
    if (simtype==1) indlevel$G <- rnorm(N, sd=sd(indlevel$g_dm))
    if (simtype==2) indlevel$G <- rnorm(N)*indlevel$g_dm
    
    indlevel$G_dm <- M_controls%*%indlevel$G
    indlevel$X_n <- indlevel$fs_coef[1] * fscoef_mult * indlevel$G_dm + indlevel$x_resid # already resid. on M_controls
    
    # Run industry-level IV, collect coef and SE. Truth is zero
    fit <- ivreg(eps_n ~ X_n + t2 | G+t2, data=indlevel, weights=s_n)
    #      fsfit <- lm(X_n ~ G+t2, data=indlevel, weights=s_n) # very weird: after lm, summary() produces wrong SE!
    fsfit <- ivreg(X_n ~ G+t2 | G+t2, data=indlevel, weights=s_n)
    BETA[s] <- fit$coefficients[2]
    if (is.null(clustervar)) {
      AKM_SE[s] <- summary(fit, vcov=sandwich)$vcov[2,2]^0.5
      Fstat[s] <- summary(fsfit, vcov=sandwich)$coefficients[2,3]^2 # 3rd column is t-stats
    }
    else {
      AKM_SE[s] <- coeftest.cluster(indlevel, fit, cluster1=clustervar)[2,2]
      Fstat[s] <- coeftest.cluster(indlevel, fsfit, cluster1=clustervar)[2,3]^2
    }
    # Does NOT exactly coincide with Stata clustered SE? Maybe DF correction?
    # Comes from https://iangow.wordpress.com/2012/01/19/iv-regression-and-two-way-cluster-robust-standard-errors/
    # Also note that I had to correct this command so that it works with weights
    
    # For Anderson-Rubin
    epsfit <- ivreg(eps_n ~ G+t2 | G+t2, data=indlevel, weights=s_n) # eps_n = eps_n - 0*X_n

    # Test AKM0 & AR rejection
    if (is.null(clustervar)) {
      AKM0_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum((s_n * eps_n * G_dm)^2)^0.5)
      AKM0_Tinf <- with(indlevel, sum(s_n*X_n*G)/sum((s_n*X_n*G_dm)^2)^0.5) 
        # replace eps with x because eps_n-1000*X_n is basically X_n
        # Old verison, also correct, below. Above we took 1000 to infinity analytically
        #AKM0_Tplus <- with(indlevel, sum(s_n*(eps_n-1000*X_n)*G) / sum((s_n * (eps_n-1000*X_n) * (M_controls%*%G))^2)^0.5)

      AR_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum((s_n * epsfit$residuals * G_dm)^2)^0.5)
    }
    else {
      clussums <- with(indlevel, tapply(s_n * eps_n * G_dm, indlevel[,clustervar], sum))
      AKM0_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum(clussums^2)^0.5)
      
      clussums_inf <-  with(indlevel, tapply(s_n * X_n * G_dm, indlevel[,clustervar], sum))
      AKM0_Tinf <- with(indlevel, sum(s_n*X_n*G) / sum(clussums_inf^2)^0.5)
      
      clussums_ar <-  with(indlevel, tapply(s_n * epsfit$residuals * G_dm, indlevel[,clustervar], sum))
      AR_T[s] <- with(indlevel, sum(s_n*eps_n*G) / sum(clussums_ar^2)^0.5)
    }
    AKM0_inf[s] <- abs(AKM0_Tinf)<1.96
    AR_inf[s] <- Fstat[s] < 1.96^2 # Andrews and Stock show that AR CI is infinite iff the first stage is insignificant
      # see https://www.nber.org/econometrics_minicourse_2018/2018si_methods.pdf, slide 45
      
    # Compute Rotember weight of top-5 industries
    indlevel$ROTweight <- with(indlevel, s_n*G*X_n) #DEMEAN?
    ROT5[s] <- with(indlevel,sum(ROTweight[rank(-ROTweight)<=5])/sum(ROTweight[ROTweight>0]))
  }
  # Return mean/median ROT5 weight and coverage for AKM and AKM0
  AKM_T <- BETA/AKM_SE
  hhi <- with(indlevel, sum(s_n^2)/sum(s_n)^2) # not clustered!
  
  results <-matrix(c(mean(abs(AKM_T)>1.96), mean(abs(AKM0_T)>1.96), mean(abs(AR_T)>1.96), mean(AKM0_inf), mean(AR_inf),
                     median(ROT5), mean(ROT5), 1/hhi, median(Fstat), mean(Fstat), 
                     median(BETA), mean(BETA), sd(BETA), mad(BETA), median(AKM_SE), mean(AKM_SE), sd(AKM_SE)),nrow=1)
  colnames(results) <- c("AKM rej rate", "AKM0 rej rate", "AR rej rate", "AKM0 inf rate", "AR inf rate",
                         "Median ROT5", "Mean ROT5", "1/HHI", "Median F", "Mean F", 
                         "Med. Bias", "Mean bias", "Simulated SD", "Simulated MAD", "Median AKM SE", "Mean AKM SE", "SD of AKM SE")
  rownames(results) <- name
  if(post.results) RESULTS <<- rbind(RESULTS,results)
  
  resmatrix <- cbind(AKM_T,AKM0_T,AR_T,AKM0_inf,AR_inf,ROT5,Fstat,BETA,AKM_SE)
  colnames(resmatrix) <- c("AKM_T","AKM0_T","AR_T","AKM0_inf","AR_inf","ROT5","Fstat","BETA","AKM_SE")
  
  return(list(results=results,resmatrix=resmatrix))
}

# Find the power alpha such that HHI(s_n^alpha)=x. Return s_n^alpha. This function increases in alpha
match_hhi <- function(s, HHI, tol=0.0001) {
  if (HHI<1/length(s)) return(NULL)
  left <- log(0.0001)
  right <- log(100)
  mid <- (left+right)/2  
  alpha <- exp(mid)
  hhi <- sum(s^(2*alpha))/(sum(s^alpha)^2)
  it <- 0
  
  while (abs(hhi/HHI - 1)>tol & it<20) {
    if (hhi<HHI) left <- mid
    else right <- mid
    mid <- (left+right)/2
    alpha <- exp(mid)
    hhi <- sum(s^(2*alpha))/(sum(s^alpha)^2)
    it <- it+1
  }
  mult <- sum(s)/sum(s^alpha)
  return(list(alpha=alpha,mult=mult))
}
