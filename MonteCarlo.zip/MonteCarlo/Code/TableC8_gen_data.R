SIM <-15000
setwd("/Users/kirillborusyak/Dropbox/Ideas/Bartik/Replication files Aug2020/Local/MonteCarlo")
source("Code/coeftest.cluster.R")
source("Code/Sim_ADH.R")

ReadADH("sic87dd")
LoadADH()

set.seed(12345)
G <- matrix(rnorm(N*SIM),nrow=N)*indlevel$g_dm
Zn <- t(shares) %*% (loclevel$wei * M_controls %*% cbind(loclevel$x_resid, shares %*% G)) /indlevel$s_n 
      # shares*G=Z_l, M_controls*Z_l=Z_l^perp, shares'*(e_l*Z_l^perp)/s_n=Z_n^perp
      # here convert both original x_resid and all simulated G
colnames(G) <- paste("G",1:SIM,sep="")
colnames(Zn) <- c("x_resid_n",paste("Z",1:SIM,sep=""))
indlevel <- cbind(indlevel,G,Zn)
G <- Zn <- NULL

write.csv(indlevel, "Data/sim_random_data.csv")
